function FootBar(){

    return(
        <>
            <footer>
                <p>&copy; 2024 G.A.I.A . All rights reserved.</p>
                <ul>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Follow Us: Instagram | Facebook | Twitter</a></li>
                </ul>
            </footer>
        </>
    );

}

export default FootBar